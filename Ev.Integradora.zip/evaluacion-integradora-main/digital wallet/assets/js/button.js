function reconnect(){
    alert("redireccionando")
    location.href="deposit.html"
}

function reconnect2(){
    alert("redireccionando")
    location.href="envio.html"
}

function reconnect3(){
    alert("redireccionando")
    location.href="ultimosmovimientos.html"
}